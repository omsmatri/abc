from flask import Flask, jsonify, request
from flask_cors import CORS
import trainer
import text_detection
app = Flask(__name__)
CORS(app)

@app.route('/api/automate',methods=['POST'])
def index():
    flag = request.json['flag']
    sub_image = request.json['sub_image']
    big_image = request.json['big_image']
    return jsonify({'msg':text_detection.brain(sub_image, big_image, flag)})

if __name__ == '__main__':
  app.run(host='127.0.0.1', port=8080, debug=True)
 
