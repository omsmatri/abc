from chatterbot import ChatBot

chatbot = ChatBot("Ironside")