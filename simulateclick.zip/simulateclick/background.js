// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Called when the user clicks on the browser action.
/*
chrome.browserAction.onClicked.addListener(function(tab) {
	const req = new XMLHttpRequest();
	const baseUrl = "http://127.0.0.1:8080/api/automate";
	const urlParams = '{"sub_image":"abcd","big_image":"defg"}';
	req.open("POST", baseUrl,true);
	req.setRequestHeader("Content-type", "application/json");
	req.send(urlParams);
	req.onreadystatechange = function(){
		if(this.readyState === XMLHttpRequest.DONE && this.status === 200){
			chrome.tabs.executeScript({
				code: 'console.log("got response 200")'
			});
			alert(req.responseText);
		}
	}
});
*/