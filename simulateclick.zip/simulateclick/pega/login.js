function goToActivityTab(){
	console.log("inside tab");
	//move the cursor to the position returned by api
}
goToActivityTab();