 function pingServer(flag){
	const req = new XMLHttpRequest();
	const baseUrl = "http://127.0.0.1:8080/api/automate";
	const urlParams = '{"sub_image":"abcd","big_image":"defg","flag":"'+flag+'"}';
	req.open("POST", baseUrl,true);
	req.setRequestHeader("Content-type", "application/json");
	req.send(urlParams);
	req.onreadystatechange = function(){
		if(this.readyState === XMLHttpRequest.DONE && this.status === 200){
			chrome.tabs.executeScript({
				code: 'console.log("got response 200")'
			});
			var resp_text_list = JSON.parse(req.responseText);
			console.log(resp_text_list);
			console.log(resp_text_list.msg.length);
			
			for(var i=0; i< resp_text_list.msg.length;i++){
				if(resp_text_list.msg[i].text == "User name"){
					console.log(resp_text_list.msg[i]);
					resp_text = JSON.stringify(resp_text_list.msg[i]);
				}
			}
			//alert(resp_text);
			chrome.tabs.executeScript({
				code: 'var mousexy='+resp_text+';mousexy;console.log(mousexy);var e1 = document.elementFromPoint((mousexy.endX+mousexy.startX)/2, (mousexy.endY+mousexy.startY)/2);console.log(e1);e1.value="dasa5";'
			});
			/*
			console.log(resp_text);
			alert(resp_text[0].msg.x);
			alert(resp_text[0].msg.y);
			alert(document.elementFromPoint(resp_text[0].msg.x,resp_text[0].msg.y));
			chrome.tabs.query({active:true, currentWindow: true}, function(tabs){
				chrome.tabs.executeScript(tabs[0].id, {code: 'var x='+resp_text+';x'}, goToActivityTab);
			});
			*/
		}
	}
};

function injectTheScript(flag){
	pingServer(flag);
}

function goToActivityTab(results){
	mousex = results[0].msg.x;
	mousey = results[0].msg.y;
	console.log("inside tab");
	chrome.tabs.executeScript({
		code: 'console.log(document.elementFromPoint(100,237))'
	});
	alert(document.elementFromPoint(mousex,mousey));
	//move the cursor to the position returned by api
	//simulateclick(mousex,mousey)
}
function simulateclick(x,y){
	var ev = new MouseEvent('click', {
		'view':window,
		'bubbles':  true,
		'cancelable': true,
		'screenX': x,
		'screenY': y
	});
	var e1 = document.elementFromPoint(x,y);
	//alert(e1);
	//e1.dispatchEvent(ev);
}


document.getElementById("login").addEventListener('click', function(){injectTheScript('login')});